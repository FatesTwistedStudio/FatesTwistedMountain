Sound of large wings flapping 3 times.

Licensing: Creative Commons Zero (CC0)

Source: fast simple chop 5 by dave.des: https://freesound.org/s/127197/
